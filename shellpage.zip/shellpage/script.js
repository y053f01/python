$(document).ready(function() {
    const description = $('#description');
    const inputLine = $('#input-line');
    const commandInput = $('#command-input');
    const outputDiv = $('#output');

    // Typewriter effect function
    function typeWriter(element, text, delay, callback) {
        let i = 0;
        function type() {
            if (i < text.length) {
                element.html(element.html() + text.charAt(i));
                i++;
                setTimeout(type, delay);
            } else if (callback) {
                callback();
            }
        }
        type();
    }

    // Function to sanitize input
    function sanitizeInput(input) {
        // Create a div element to use the browser's built-in text handling
        const div = document.createElement('div');
        div.appendChild(document.createTextNode(input));
        return div.innerHTML;
    }

    // Command history array
    let commandHistory = [];
    let historyIndex = -1;

    // Start the typewriter effect
    description.removeClass('hidden');
    typeWriter($('#welcome-text'), 'Welcome to My shellpage', 50, function() {
        typeWriter($('#instruction-text'), " Type 'help' to see the list of available commands.", 40, function() {
            inputLine.removeClass('hidden');
            commandInput.focus(); // Focus on the input field
        });
    });

    // Handle keydown events on the command input
    commandInput.on('keydown', function(event) {
        switch (event.key) {
            case 'Enter':
                handleEnterKey();
                break;
            case 'ArrowUp':
                navigateCommandHistory('up');
                break;
            case 'ArrowDown':
                navigateCommandHistory('down');
                break;
            default:
                // Reset history index when typing a new command
                historyIndex = -1;
        }
    });

    // Function to handle 'Enter' key press
    function handleEnterKey() {
        let input = commandInput.val().trim();
        let sanitizedInput = sanitizeInput(input);

        if (sanitizedInput !== '') {
            // Add command to history
            commandHistory.unshift(sanitizedInput);

            // Process command
            let output = '';
             // you can add  many commands as needed
            switch (sanitizedInput.toLowerCase()) {
                case 'whoami':
                    output = '<div id="whoami">Add your info</div>';
                    break;
                case 'skills':
                    // you can repeat those elements many times as needed.
                    output = `
                    <div id="skills-a">Discreption of skills</div>
                    <div id="skills-b">title:</div>
                    <div id="skills-c">your progress bar or anything</div>
                     
                    `;
                    break;
                case 'projects':

                    output = `
                        <div id="project-link">1. <a href="yourLinkToTheFile" target="_blank">name of the file</a> - A description for the project. </div>
                    `;
                    break;
                case 'certificates':
                     // you can repeat those element many times as needed.
                    output = `
                        <div class="certificates">
                            <div id="certs">
                                <div id="title">title of the certificate</div>
                                <a href="images/cert1.jpg" target="_blank"><img src="images/cert1.jpg" alt="Certificate image"></a>
                                <div id="descimg">Description for the certificate
                                </div>
                            </div>
                        </div>
                    `;
                    break;
                case 'help':
                    output = '<div id="commands">Available commands:\n\nwhoami\nskills\nprojects\ncertificates\nhelp</div>';
                    break;
                default:
                    output = '<div id="command-error"> Command not found: ' + sanitizedInput + '</div>';
            }

            // Display command and output in terminal
            outputDiv.append(`<div class="executed-command">${$('#prompt').text()} ${sanitizedInput}</div><div>${output}</div>`);
        }

        // Clear input field
        commandInput.val('');

        // Reset history index after submitting command
        historyIndex = -1;
    }

    // Function to navigate command history
    function navigateCommandHistory(direction) {
        if (commandHistory.length === 0) {
            return;
        }

        if (direction === 'up') {
            // Move to previous command in history
            historyIndex = Math.min(historyIndex + 1, commandHistory.length - 1);
        } else if (direction === 'down') {
            // Move to next command in history
            historyIndex = Math.max(historyIndex - 1, -1);
        }

        // Update input field with history command
        if (historyIndex !== -1) {
            commandInput.val(commandHistory[historyIndex]);
        } else {
            commandInput.val(''); // Clear input if no history command found
        }
    }
});
